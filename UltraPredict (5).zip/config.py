# API Configuration
API_KEY = "d5a624a78e958cdc1373754ad2b89950"
