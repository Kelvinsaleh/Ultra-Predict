#!/bin/bash
python3 fetch_data.py
python3 predict.py
python3 database.py
