document.addEventListener("DOMContentLoaded", () => {
    fetch("predictions.json")
        .then(response => response.json())
        .then(data => {
            const table = document.getElementById("predictions");
            const correctScoreTable = document.getElementById("correct-score");
            const betOfTheDayTable = document.getElementById("bet-of-the-day");

            data.forEach(prediction => {
                const row = `
                    <tr>
                        <td>${prediction.match}</td>
                        <td><strong>${prediction.prediction}</strong></td>
                        <td>${prediction.odds}</td>
                        <td>${prediction.date}</td>
                        <td>${prediction.time}</td>
                    </tr>
                `;

                if (table) table.innerHTML += row;

                // Correct Score page (only exact score bets)
                if (correctScoreTable && prediction.prediction.includes("-")) {
                    correctScoreTable.innerHTML += row;
                }

                // Bet of the Day (first match in JSON)
                if (betOfTheDayTable && data.indexOf(prediction) === 0) {
                    betOfTheDayTable.innerHTML += row;
                }
            });
        })
        .catch(err => console.error("Error fetching predictions:", err));
});