import os
import requests
import json
import sqlite3
from datetime import datetime
from apscheduler.schedulers.blocking import BlockingScheduler

# Load API Key from environment variable
API_KEY = os.getenv("API_KEY", "your-default-key")  # Replace default
BASE_URL = "https://v3.football.api-sports.io"
HEADERS = {"x-apisports-key": API_KEY}
DB_FILE = "ultrapredict.db"

def fetch_matches():
    """Fetch today's football matches dynamically."""
    today = datetime.today().strftime('%Y-%m-%d')
    url = f"{BASE_URL}/fixtures?date={today}"
    response = requests.get(url, headers=HEADERS)
    
    if response.status_code == 200:
        data = response.json()
        return data.get("response", [])
    else:
        print("Error fetching matches:", response.text)
        return []

def create_tables():
    """Ensure the database and table exist."""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            match_id INTEGER UNIQUE,
            home_team TEXT,
            away_team TEXT,
            prediction TEXT,
            confidence REAL,
            match_date TEXT
        )
    """)
    conn.commit()
    conn.close()

def update_predictions():
    """Fetch matches and store predictions."""
    create_tables()
    matches = fetch_matches()
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    for match in matches:
        match_id = match['fixture']['id']
        home_team = match['teams']['home']['name']
        away_team = match['teams']['away']['name']
        prediction = "Home Win"  # Placeholder prediction logic
        confidence = 0.75  # Placeholder confidence
        match_date = match['fixture']['date']
        
        cursor.execute("""
            INSERT INTO matches (match_id, home_team, away_team, prediction, confidence, match_date)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(match_id) DO UPDATE SET
            prediction=excluded.prediction,
            confidence=excluded.confidence,
            match_date=excluded.match_date
        """, (match_id, home_team, away_team, prediction, confidence, match_date))
    
    conn.commit()
    conn.close()
    print("Predictions updated successfully!")

# Scheduler to run every 6 hours
scheduler = BlockingScheduler()
scheduler.add_job(update_predictions, 'interval', hours=6)

if __name__ == "__main__":
    print("Starting scheduled task...")
    scheduler.start()
